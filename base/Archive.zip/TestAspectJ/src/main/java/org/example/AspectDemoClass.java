package org.example;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AspectDemoClass {

    @Pointcut("execution(public * org.example.DemoClass.test())")
    public void cutTest() {}

    @AfterReturning(pointcut = "cutTest()")
    public void testReturn(JoinPoint joinPoint) {
        System.out.println("finish point cut");
        System.out.println("test ok ===");
    }
}
