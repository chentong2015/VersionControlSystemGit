package org.example;

public class DemoClass {

    public void test() {
        System.out.println("test demo class");
    }
}
